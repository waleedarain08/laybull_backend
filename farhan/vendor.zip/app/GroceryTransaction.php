<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GroceryTransaction extends Model
{
    protected $table = 'grocery_transactions';
}
