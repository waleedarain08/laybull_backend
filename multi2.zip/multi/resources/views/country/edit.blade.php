@extends('layouts.app',['page' => __('Edit Country'), 'pageSlug' => 'countries.edit'])
@section('content')
    <!-- Main content -->
    <section class="content">
        <div class="container">
            <form id="products-form" action="{{ route('countries.update', $country->id) }}" method="POST" enctype="multipart/form-data" >
                @csrf
                <input name="_method" type="hidden" value="PUT">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <div class="card card-primary">
                            <div class="card-header">
                                <h3 class="card-title">Edit Country</h3>
                                <div class="card-tools">

                                </div>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-12 col-sm-4">
                                        <div class="form-group">
                                            <label for="name">Country Name</label>
                                            <input type="text" id="country_name" name="country_name" class="form-control" value="{{ $country->country_name }}">
                                        </div>
                                    </div>

                                    <div class="col-md-12 col-sm-4">
                                        <div class="form-group">
                                            <label for="price">Country Short Name</label>
                                            <input type="text" id="country_sname" name="country_sname" class="form-control" value="{{$country->country_sname}}">
                                        </div>
                                    </div>

                                </div>
                                <!-- 2nd row starts here -->
                                <div class="row">
                                    <div class="col-md-12 col-sm-4">
                                        <div class="form-group">
                                            <label for="color">Country Shipment Charges</label>
                                            <input type="text" id="country_scharges" name="country_scharges" value="{{ $country->country_scharges }}" class="form-control" placeholder="Enter a country shipment charges">
                                        </div>
                                    </div>
                                    <div class="col-md-12 col-sm-4">
                                        <div class="form-group">
                                            <label for="color">Price With</label>
                                            <input type="text" id="price_with" name="price_with" value="{{ $country->price_with }}" class="form-control" placeholder="Enter a country price">
                                        </div>
                                    </div>
                                </div><!-- /.2nd row ends -->

                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <a href="{{route('countries.index')}}" class="btn btn-secondary">Cancel</a>
                        <input type="submit" value="Update Country" class="btn btn-success float-right">
                    </div>
                </div>
            </form>
        </div>
    </section>


    <!-- /.content -->


@endsection

