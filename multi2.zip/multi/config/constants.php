<?php

return [

    'modules' => [
        'food' => 'Food',
        'grocery' => 'Grocery',
        'store' => 'Store',
        'hotel' => 'Hotel',
        'car' => 'Car' 
    ]
];