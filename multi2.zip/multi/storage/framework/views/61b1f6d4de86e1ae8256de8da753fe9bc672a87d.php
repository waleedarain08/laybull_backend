<?php $__env->startSection('content'); ?>
<!-- Main content -->
<section class="content">
    <div class="container">
        <!-- Default box -->
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-6">
                        <h3 class="card-title">Brands</h3>
                    </div>
                    <div class="col-md-6">
                        <a href="<?php echo e(route('brands.create')); ?>" class="nav-link pull-right">
                            <button class="btn btn-primary form-control text-capitalize">Add Brand</button>
                        </a>
                    </div>
                </div>
            </div>

            <div class="card-body p-0" style="padding:5px !important;">
                <?php echo $__env->make('alert2.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <table class="table table-striped projects data-table">
                    <thead>
                        <tr>
                        <?php $__currentLoopData = $display; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th style="">
                                <?php echo e($disp); ?>

                            </th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key+1); ?></td>
                            <td><?php echo e($record->name); ?></td>
                            <td><img src="<?php echo e(asset($record->picture ? 'uploads/brandImages/'.$record->picture: 'images/noImage.png')); ?>" alt="" width="100" height="100"></td>
                            <td ><?php echo e($record->description); ?></td>
                            <td ><?php echo e($record->created_at); ?></td>
                            <td colspan="2"><a href="brands/<?php echo e($record->id); ?>/edit" class="btn btn-info btn-sm float-left">Edit</a>
                                <form method="post" action="<?php echo e(route('brands.destroy',$record->id)); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field("DELETE")); ?>

                                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                </form>
                            </td>
                            <td>
                                <?php if($record->status == 1): ?>
                                    <a href="<?php echo e(route('category.edit',$record->id)); ?>" class="switch">
                                        <input type="checkbox" checked>
                                        <span class="slider round"></span>
                                    </a>
                                <?php else: ?>
                                    <a href="" class="switch">
                                        <input type="checkbox" >
                                        <span class="slider round"></span>
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <!-- /.card-body -->
        </div>
        <?php echo e($records->links()); ?>

    </div>
    <!-- /.card -->
</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

















<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app',['page' => __('Brands'), 'pageSlug' => 'brands'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Projects Laravel\Habib Ur Rehman\multi\resources\views/brand/index.blade.php ENDPATH**/ ?>