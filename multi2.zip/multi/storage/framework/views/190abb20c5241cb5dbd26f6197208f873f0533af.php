<?php $__env->startSection('sideheading'); ?>
     <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Add Brand</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Brand</a></li>
              <li class="breadcrumb-item active">Add Brand</li>
            </ol>
          </div>
        </div>
        <div class="row mb-2">
          <div class="col-sm-12">
            <?php if(Session::has('success')): ?>
            <!-- <div class="alert alert-success"> -->
                <p class="alert alert-success"><?php echo e(Session::get('success')); ?></p>
            <!-- </div> -->
            <?php endif; ?>
          </div>
          <div class="col-sm-12">
            <?php if(Session::has('errors')): ?>
            <!-- <div class="alert alert-success"> -->
                <p class="alert alert-danger"><?php echo e(Session::get('errors')); ?></p>
            <!-- </div> -->
            <?php endif; ?>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Main content -->
<section class="content">
    <div class="container">
        <form id="brand-form" action="<?php echo e(route('brands.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Add Brand</h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12 col-sm-4">
                                    <div class="form-group">
                                        <label for="name">Name</label>
                                        <input type="text" id="name" name="name" class="form-control" placeholder="i.e Khadi" required>
                                    </div>
                                </div>

                                <div class="col-md-12 col-sm-4">
                                    <label for="picture">Picture</label>
                                    <div class="form-control" >
                                        <input type="file" id="picture" name="picture" style="padding:2px;" required>
                                    </div>
                                </div>

                                <div class="col-md-12 col-sm-4">
                                    <div class="form-group">
                                        <label for="description">Description</label>
                                        <textarea type="text" id="description" name="description" class="form-control" placeholder="i.e clothes brand" rows="5" cols="5"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                <!-- <a href="#" class="btn btn-secondary">Cancel</a> -->
                <input type="submit" value="Create new Brand" class="btn btn-success float-right">
                </div>
            </div>
        </form>
    </div>
</section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app',['page' => __(' Brands'), 'pageSlug' => 'brands.create'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Usman\First Project\multi\resources\views/brand/create.blade.php ENDPATH**/ ?>