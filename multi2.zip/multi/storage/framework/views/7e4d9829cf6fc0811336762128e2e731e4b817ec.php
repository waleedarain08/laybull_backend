<?php if(Session::has('insert')): ?>
<div class="alert alert-success alert-dismissible">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong><?php echo e(Session::get('insert')); ?></strong>
</div>

<?php endif; ?>
<?php if(Session::has('status')): ?>
<div class="alert alert-success alert-dismissible">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong><?php echo e(Session::get('status')); ?></strong>
</div>

<?php endif; ?>
<?php if(Session::has('update')): ?>
<div class="alert alert-primary alert-dismissible">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong><?php echo e(Session::get('update')); ?></strong>
</div>
<?php endif; ?>
<?php if(Session::has('delete')): ?>
<div class="alert alert-danger alert-dismissible">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong><?php echo e(Session::get('delete')); ?></strong>
</div>
<?php endif; ?>
<?php /**PATH G:\Projects Laravel\Habib Ur Rehman\multi\resources\views/alert2/message.blade.php ENDPATH**/ ?>