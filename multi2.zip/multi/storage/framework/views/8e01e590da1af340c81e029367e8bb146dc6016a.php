<?php $__env->startSection('content'); ?>
<section class="content">
<div class="container">
<div class="card">
    <div class="card-header">
        <div class="row">
            <div class="col-md-6">
                <h3 class="card-title">Products</h3>
            </div>
            <div class="col-md-6">
                <a href="<?php echo e(route('products.create')); ?>" class="nav-link pull-right">
                    <button class="btn btn-primary form-control text-capitalize">Add Product</button>
                </a>
            </div>
        </div>
    </div>

    <div class="card-body p-0" style="padding:5px !important;">
        <?php echo $__env->make('alert2.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <table class="table table-striped projects data-table" style="">
            <thead>
                <tr>
                <?php $__currentLoopData = $display; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th class="<?php echo e($disp == 'Action' ? 'text-center' : ''); ?>">
                        <?php echo e($disp); ?>

                    </th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td style="width: 18.6%"><?php echo e($record->name); ?></td>
                    <td>
                        <img src="<?php echo e(asset($record->feature_image ? 'uploads/productImages/'.$record->feature_image : 'Images/noImage.png')); ?>" alt="" width="100" height="100">
                    </td>
                    <td><?php echo e($record->category()->pluck('name')->implode('name')); ?></td>
                    <td><?php echo e($record->user()->pluck('name')->implode('name')); ?></td>
                    <td><?php echo e($record->price); ?></td>
                    <td>
                        <?php if($record->popular == 0): ?>
                            NO
                        <?php else: ?>
                            YES
                        <?php endif; ?>
                    </td>
                    <td><?php echo $record->status ? '<span class="text-success">Approved</span>' : 'In-Review'; ?></td>
                    <td>
                        <a class="btn btn-primary btn-sm float-left mr-1" href="products/<?php echo e($record->id); ?>">
                                <i class="fas fa-eye">
                                    </i>
                        </a>
                        <a class="btn btn-info btn-sm float-left mr-1" href="products/<?php echo e($record->id); ?>/edit">
                                <i class="fas fa-pencil-alt">
                                    </i>
                        </a>
                        <form method="post" action="<?php echo e(route('products.destroy',$record->id)); ?>" class="">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field("DELETE")); ?>

                            <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash-alt">
                                </i></button>
                        </form>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

        <div class="text-center w-100"><?php echo e($records->links()); ?></div>

</div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app',['page' => __('Product List'), 'pageSlug' => 'products'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Projects Laravel\Habib Ur Rehman\multi\resources\views/product/index.blade.php ENDPATH**/ ?>