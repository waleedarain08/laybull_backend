<?php $__env->startSection('content'); ?>
<!-- Main content -->
<section class="content">
    <div class="container">
    <form id="products-form" action="<?php echo e(route('products.update', $product->id)); ?>" method="POST" enctype="multipart/form-data" >
            <?php echo csrf_field(); ?>
            <input name="_method" type="hidden" value="PUT">
    <div class="row">
    <div class="col-md-12 col-sm-12">
        <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title">Edit Product</h3>
            <div class="card-tools">

            </div>
        </div>
        <div class="card-body">
        <div class="row">
        <div class="col-md-12 col-sm-4">
            <div class="form-group">
            <label for="vendor">By Vendor</label>
                <input type="text" class="form-control" value="<?php echo e($vendor_name); ?>" readonly>
                <input type="hidden" id="vendor" name="vendor" class="form-control" readonly value="<?php echo e($vendor_id); ?>">
            </div>
            </div>
        <div class="col-md-12 col-sm-4">
            <div class="form-group">
            <label for="name">Name</label>
            <input type="text" id="name" name="name" class="form-control" value="<?php echo e($product->name); ?>">
            </div>
        </div>

        <div class="col-md-12 col-sm-4">
            <div class="form-group">
            <label for="cat_id">Category</label>
            <select id="cat_id" name="cat_id" class="form-control custom-select">
                <option selected disabled>Select one</option>
                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat->id); ?>" <?php if($cat->id == $product->category_id): ?> selected <?php endif; ?>><?php echo e($cat->name.' ('.$cat->easy_commission.'%)'); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            </div>
        </div>

            <div class="col-md-12 col-sm-4">
                <div class="form-group" >
                    <label for="image">Feature Image</label>
                    <input type="file" id="feature_image" name="feature_image" class="form-control" style="padding:12px;">
                    <img src="<?php echo e(asset($product->feature_image ? 'uploads/productImages/'.$product->feature_image : 'images/noImage.png')); ?>" alt=""  width="100" height="100">
                </div>
            </div>
            <div class="col-md-12 col-sm-4">
            <div class="form-group">
            <label for="brand_id">Brand</label>
            <select id="brand_id" name="brand_id" class="form-control custom-select">
                <option disabled>Select One</option>
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($brand->id); ?>" <?php if($brand->id == $product->brand_id): ?> selected <?php endif; ?>><?php echo e($brand->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            </div>
            </div>

            <div class="col-md-12 col-sm-4">
            <div class="form-group">
            <label for="price">Price</label>
            <input type="text" id="price" name="price" class="form-control" value="<?php echo e($product->price); ?>">
            </div>
        </div>

        </div>
        <!-- 2nd row starts here -->
        <div class="row">
            <div class="col-md-12 col-sm-4">
                <div class="form-group">
                    <label for="color">Color</label>
                    <input type="text" id="color" name="color" value="<?php echo e($product->color); ?>" class="form-control" placeholder="Enter a Color">
                </div>
            </div>
            <div class="col-md-12 col-sm-4">
                <div class="form-group">
                    <label for="size">Size</label>
                    <select id="size" name="size" class="form-control custom-select" required>
                        <option value="0" >none</option>
                        <option value="XS" <?php if($product->size == 'XS'): ?> selected <?php endif; ?>>XS</option>
                        <option value="S" <?php if($product->size == 'S'): ?> selected <?php endif; ?>>S</option>
                        <option value="M" <?php if($product->size == 'M'): ?> selected <?php endif; ?>>M</option>
                        <option value="L" <?php if($product->size == 'L'): ?> selected <?php endif; ?>>L</option>
                        <option value="XL" <?php if($product->size == 'XL'): ?> selected <?php endif; ?>>XL</option>
                        <option value="XXL" <?php if($product->size == 'XXL'): ?> selected <?php endif; ?>>XXL</option>
                    </select>
                </div>
            </div>
            <div class="col-md-12 col-sm-4">
                <div class="form-group">
                    <label for="condition">Condition</label>
                    <select id="condition" name="condition" class="form-control custom-select" required>
                        <option value="0" >none</option>
                        <option value="NEW" <?php if($product->condition == 'NEW'): ?> selected <?php endif; ?>>NEW</option>
                        <option value="USED" <?php if($product->condition == 'USED'): ?> selected <?php endif; ?>>USED</option>
                    </select>
                </div>
            </div>
            <div class="col-md-12 col-sm-4">
                <div class="form-group">
                    <label for="popularProduct">Popular Product</label>
                    <select id="popularProduct" name="popular" class="form-control custom-select" required>
                        <option value="0" >none</option>
                        <option value="1" <?php if($product->popular == 1): ?> selected <?php endif; ?>>YES</option>
                        <option value="0" <?php if($product->popular == 0): ?> selected <?php endif; ?>>NO</option>
                    </select>
                </div>
            </div>
            <div class="col-md-12 col-sm-4">
                <label for="image">More Images</label>
                <span>If you add More Images then previous images will be deleted..</span>
                <div class="form-control">
                    <input type="file" id="image" name="images[]" placeholder="Enter a Images" multiple>
                </div>
            </div>
            <div class="col-md-12 col-sm-4">
                <div class="form-group">
                    <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset($image->image)); ?>" alt=""  width="100" height="100">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-md-12 col-sm-4">
                <div class="form-group">
                <label for="short_desc">Short Desc:</label>
                    <textarea id="short_desc" name="short_desc" class="form-control" rows="4"><?php echo e($product->short_desc); ?></textarea>
                </div>
            </div>
        </div><!-- /.2nd row ends -->

        </div>
        <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
    </div>

    <div class="row">
    <div class="col-12">
        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">Cancel</a>
        <input type="submit" value="Update Product" class="btn btn-success float-right">
    </div>
    </div>
    </form>
    </div>
</section>


    <!-- /.content -->


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app',['page' => __('Edit Product'), 'pageSlug' => 'product.edit'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Usman\First Project\multi\resources\views/product/edit.blade.php ENDPATH**/ ?>