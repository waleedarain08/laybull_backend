<?php if(auth()->check()): ?>
    <div class="sidebar">
        <div class="sidebar-wrapper">
            <div class="logo">
                
                <h2 class="p-4 m-4">LAYBULL</h2>
            </div>
            <ul class="nav">
                <li  class="<?php echo e($pageSlug == 'dashboard' ? 'active':''); ?>" style="<?php echo e($pageSlug == 'dashboard' ? 'background-color: black;' : ''); ?>">
                    <a href="<?php echo e(route('home')); ?>">
                        <i class="tim-icons icon-chart-pie-36"></i>
                        <p><?php echo e(__('Dashboard')); ?></p>
                    </a>
                </li>
                <li>
                    <a data-toggle="collapse" href="#laravel-examples" aria-expanded="true">
                        <i class="fas fa-users" ></i>
                        <span class="nav-link-text" ><?php echo e(__('Users')); ?></span>
                        <b class="caret mt-1"></b>
                    </a>
                    <div class="<?php echo e($pageSlug == 'profile' ? 'collapse.show' : ''); ?> <?php echo e($pageSlug == 'users' ? 'collapse.show':''); ?> collapse" id="laravel-examples">
                        <ul class="nav pl-4">
                        <li class="<?php echo e($pageSlug == 'reset' ? 'active' : ''); ?>" style="<?php echo e($pageSlug == 'reset' ? 'background-color:black;' : ''); ?>">
                                <a href="<?php echo e(route('profile.edit')); ?>">
                                    <i class="tim-icons icon-single-02"></i>
                                    <p><?php echo e(__('Reset Password')); ?></p>
                                </a>
                            </li>
                            <?php if(auth()->user()->role == 'admin'): ?>
                                <li class="<?php echo e($pageSlug == 'users' ? 'active' : ''); ?>" style="<?php echo e($pageSlug == 'users' ? 'background-color:black;' : ''); ?>">
                                    <a href="<?php echo e(route('user.index')); ?>">
                                        <i class="tim-icons icon-bank"></i>
                                        <p><?php echo e(__('Vendors Management')); ?></p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </li>
                <li>
                    <a data-toggle="collapse" href="#categories" aria-expanded="true">
                        <i class="fas fa-copyright" ></i>
                        <span class="nav-link-text" ><?php echo e(__('Categories')); ?></span>
                        <b class="caret mt-1"></b>
                    </a>
                    <div class="<?php echo e($pageSlug == 'categories' ? 'active' : ''); ?> <?php echo e($pageSlug == 'categories' ? 'collapse.show' : ''); ?> collapse" id="categories">
                        <ul class="nav pl-4">
                            <li class="<?php echo e($pageSlug == 'categories' ? 'active':''); ?>" style="<?php echo e($pageSlug == 'categories' ? 'background-color:black;' : ''); ?>">
                                <a href="<?php echo e(route('categories.index')); ?>">
                                    <i class="tim-icons icon-single-02"></i>
                                    <p><?php echo e(__('All Categories')); ?></p>
                                </a>
                            </li>

                        </ul>
                    </div>
                </li>
                <li>
                    <a data-toggle="collapse" href="#brands" aria-expanded="true">
                        <i class="fab fa-adn" ></i>
                        <span class="nav-link-text" ><?php echo e(__('Brands')); ?></span>
                        <b class="caret mt-1"></b>
                    </a>
                    <div class="<?php echo e($pageSlug == 'brands' ? 'active' : ''); ?> <?php echo e($pageSlug == 'brands' ? 'collapse.show' : ''); ?> collapse" id="brands">
                        <ul class="nav pl-4">
                            <li class="<?php echo e($pageSlug == 'brands' ? 'active' : ''); ?>" style="<?php echo e($pageSlug == 'brands' ? 'background-color:black;' : ''); ?>">
                                <a href="<?php echo e(route('brands.index')); ?>">
                                    <i class="tim-icons icon-single-02"></i>
                                    <p><?php echo e(__('Brands')); ?></p>
                                </a>
                            </li>

                        </ul>
                    </div>
                </li>
                <li>
                    <a data-toggle="collapse" href="#products" aria-expanded="true">
                        <i class="fab fa-product-hunt" ></i>
                        <span class="nav-link-text" ><?php echo e(__('Products')); ?></span>
                        <b class="caret mt-1"></b>
                    </a>
                    <div class="<?php echo e($pageSlug == 'products' ? 'active' : ''); ?><?php echo e($pageSlug == 'products' ? 'collapse.show' : ''); ?> collapse" id="products">
                        <ul class="nav pl-4">
                            <li class="<?php echo e($pageSlug == 'products' ? 'active' : ''); ?>" style="<?php echo e($pageSlug == 'products' ? 'background-color:black;' : ''); ?>">
                                <a href="<?php echo e(route('products.index')); ?>">
                                    <i class="tim-icons icon-single-02"></i>
                                    <p><?php echo e(__('Products')); ?></p>
                                </a>
                            </li>

                        </ul>
                    </div>
                </li>
             <?php if(in_array("food", explode(',', auth()->user()->modules))): ?>
                    <li>
                        <a data-toggle="collapse" href="#laravel-examples1" aria-expanded="true">
                            <i class="fab fa-laravel" ></i>
                            <span class="nav-link-text" ><?php echo e(__('FOODS')); ?></span>
                            <b class="caret mt-1"></b>
                        </a>

                        <div class="<?php echo e($pageSlug == 'foodcategory' ?'collapse.show':''); ?><?php echo e($pageSlug == 'foodproduct' ?'collapse.show':''); ?><?php echo e($pageSlug == 'foodproductreview' ?'collapse.show':''); ?><?php echo e($pageSlug == 'foodvendorreview' ?'collapse.show':''); ?><?php echo e($pageSlug == 'foodreservation' ?'collapse.show':''); ?>collapse" id="laravel-examples1">
                            <ul class="nav pl-4">
                            <li class="<?php echo e($pageSlug =='foodcategory' ? 'active':''); ?>" style="<?php echo e($pageSlug == 'foodcategory'?'background-color:black;':''); ?>">
                                <a href="<?php echo e(route('foodcategory.index')); ?>">
                                    <i class="tim-icons icon-atom"></i>
                                    <p><?php echo e(__('Food Category')); ?></p>
                                </a>
                            </li>
                        <li class="<?php echo e($pageSlug == 'foodproduct'?'active':''); ?>" style="<?php echo e($pageSlug == 'foodproduct'?'background-color:black;':''); ?>">
                                    <a href="<?php echo e(route('food.index')); ?>">
                                        <i class="tim-icons icon-bullet-list-67"></i>
                                        <p><?php echo e(__('Food Products')); ?></p>
                                    </a>
                                </li>
                                <li class="<?php echo e($pageSlug == 'foodproductreview'?'active':''); ?>" style="<?php echo e($pageSlug == 'foodproductreview'?'background-color:black;':''); ?>">
                                    <a href="<?php echo e(route('foodProductReview')); ?>">
                                        <i class="tim-icons icon-bullet-list-67"></i>
                                        <p><?php echo e(__('Food Products Review')); ?></p>
                                    </a>
                                </li><li class="<?php echo e($pageSlug == 'foodvendorreview'?'active':''); ?>" style="<?php echo e($pageSlug == 'foodvendorreview'?'background-color:black;':''); ?>">
                                    <a href="<?php echo e(route('foodVendorReview')); ?>">
                                        <i class="tim-icons icon-bullet-list-67"></i>
                                        <p><?php echo e(__('Food Vendor Review')); ?></p>
                                    </a>
                                </li>
                                <?php if(auth()->user()->role == 'admin' || auth()->user()->reservation): ?>
                                    </li><li class="<?php echo e($pageSlug == 'foodreservation'?'active':''); ?>" style="<?php echo e($pageSlug == 'foodreservation'?'background-color:black;':''); ?>">
                                        <a href="<?php echo e(route('reservation.index')); ?>">
                                            <i class="tim-icons icon-bullet-list-67"></i>
                                            <p><?php echo e(__('Food Reservation')); ?></p>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </li>
                <?php endif; ?>

                <?php if(in_array("grocery", explode(',', auth()->user()->modules))): ?>
                    <li>
                        <a data-toggle="collapse" href="#laravel-examples2" aria-expanded="true">
                            <i class="fab fa-laravel" ></i>
                            <span class="nav-link-text" ><?php echo e(__('Grocery')); ?></span>
                            <b class="caret mt-1"></b>
                        </a>

                        <div class="<?php echo e($pageSlug=='grocerycategory' ? 'collapse.show' : ' '); ?><?php echo e($pageSlug=='groceryproduct' ? 'collapse.show':''); ?><?php echo e($pageSlug=='groceryproductreviews' ? 'collapse.show':''); ?><?php echo e($pageSlug=='groceryvendorreviews' ? 'collapse.show':''); ?>collapse" id="laravel-examples2">
                            <ul class="nav pl-4">
                            <li class="<?php echo e($pageSlug =='grocerycategory' ? 'active':''); ?>" style="<?php echo e($pageSlug == 'grocerycategory'?'background-color:black;':''); ?>">
                                <a href="<?php echo e(route('grocerycategory.index')); ?>">
                                    <i class="tim-icons icon-atom"></i>
                                    <p><?php echo e(__('Grocery Category')); ?></p>
                                </a>
                            </li>
                            <li class="<?php echo e($pageSlug =='groceryproduct' ? 'active':''); ?>" style="<?php echo e($pageSlug == 'groceryproduct'?'background-color:black;':''); ?>">
                                <a href="<?php echo e(route('groceryproduct.index')); ?>">
                                    <i class="tim-icons icon-bullet-list-67"></i>
                                    <p><?php echo e(__('Grocery Products')); ?></p>
                                </a>
                            </li>
                            <li class="<?php echo e($pageSlug =='groceryproductreviews' ? 'active':''); ?>" style="<?php echo e($pageSlug == 'groceryproductreviews'?'background-color:black;':''); ?>">
                                <a href="<?php echo e(route('groceryProductReview')); ?>">
                                    <i class="tim-icons icon-bullet-list-67"></i>
                                    <p><?php echo e(__('Grocery Products Reviews')); ?></p>
                                </a>
                            </li>
                            <li class="<?php echo e($pageSlug =='groceryvendorreviews' ? 'active':''); ?>" style="<?php echo e($pageSlug == 'groceryvendorreviews'?'background-color:black;':''); ?>">
                                <a href="<?php echo e(route('groceryVendorReview')); ?>">
                                    <i class="tim-icons icon-bullet-list-67"></i>
                                    <p><?php echo e(__('Grocery Vendor Reviews')); ?></p>
                                </a>
                            </li>
                        </ul>
                        </div>
                    </li>
                <?php endif; ?>

                <?php if(in_array("store", explode(',', auth()->user()->modules))): ?>
                    <li>
                        <a data-toggle="collapse" href="#laravel-examples3" aria-expanded="true">
                            <i class="fab fa-laravel" ></i>
                            <span class="nav-link-text" ><?php echo e(__('Store')); ?></span>
                            <b class="caret mt-1"></b>
                        </a>

                        <div class="<?php echo e($pageSlug == 'storecategory' ? 'collapse.show':''); ?><?php echo e($pageSlug == 'storeproduct' ? 'collapse.show':''); ?><?php echo e($pageSlug == 'storeproductreviews' ? 'collapse.show':''); ?><?php echo e($pageSlug == 'storevendorreviews' ? 'collapse.show':''); ?>collapse" id="laravel-examples3">
                            <ul class="nav pl-4">
                        <li class="<?php echo e($pageSlug == 'storecategory' ? 'active':''); ?>" style="<?php echo e($pageSlug == 'storecategory' ? 'background-color:black':''); ?>">
                            <a href="<?php echo e(route('storecategory.index')); ?>">
                                <i class="tim-icons icon-atom"></i>
                                <p><?php echo e(__('Store Category')); ?></p>
                            </a>
                        </li>
                        <li class="<?php echo e($pageSlug == 'storeproduct' ? 'active' : ''); ?>" style="<?php echo e($pageSlug == 'storeproduct'? 'background-color:black':''); ?>">
                                    <a href="<?php echo e(route('storeproduct.index')); ?>">
                                        <i class="tim-icons icon-bullet-list-67"></i>
                                        <p><?php echo e(__('Store Products')); ?></p>
                                    </a>
                                </li>
                                <li class="<?php echo e($pageSlug == 'storeproductreviews' ? 'active' : ''); ?>" style="<?php echo e($pageSlug == 'storeproductreviews'? 'background-color:black':''); ?>">
                                    <a href="<?php echo e(route('storeProductReviews')); ?>">
                                        <i class="tim-icons icon-bullet-list-67"></i>
                                        <p><?php echo e(__('Store Products Reviews')); ?></p>
                                    </a>
                                </li>
                                <li class="<?php echo e($pageSlug == 'storevendorreviews' ? 'active' : ''); ?>" style="<?php echo e($pageSlug == 'storevendorreviews'? 'background-color:black':''); ?>">
                                    <a href="<?php echo e(route('storeVendorReviews')); ?>">
                                        <i class="tim-icons icon-bullet-list-67"></i>
                                        <p><?php echo e(__('Store Vendor Reviews')); ?></p>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                <?php endif; ?>

                <?php if(in_array("hotel", explode(',', auth()->user()->modules))): ?>
                    <li>
                        <a data-toggle="collapse" href="#laravel-examples4  " aria-expanded="true">
                            <i class="fab fa-laravel" ></i>
                            <span class="nav-link-text" ><?php echo e(__('Hotel')); ?></span>
                            <b class="caret mt-1"></b>
                        </a>

                        <div class="<?php echo e($pageSlug == 'hotel' ? 'collapse.show':''); ?><?php echo e($pageSlug == 'hotelreview' ? 'collapse.show':''); ?>collapse" id="laravel-examples4">
                            <ul class="nav pl-4">
                        <li class="<?php echo e($pageSlug == 'hotel' ? 'active' : ''); ?>" style="<?php echo e($pageSlug=='hotel' ? 'background-color:black':''); ?>">
                            <a href="<?php echo e(route('hotel.index')); ?>">
                                <i class="tim-icons icon-atom"></i>
                                <p><?php echo e(__('Hotel List')); ?></p>
                            </a>
                        </li>
                        <li class="<?php echo e($pageSlug == 'hotelreview' ? 'active' : ''); ?>" style="<?php echo e($pageSlug=='hotelreview' ? 'background-color:black':''); ?>">
                                    <a href="<?php echo e(route('review')); ?>">
                                        <i class="tim-icons icon-bullet-list-67"></i>
                                        <p><?php echo e(__('Hotel Reviews')); ?></p>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                <?php endif; ?>

                <?php if(in_array("car", explode(',', auth()->user()->modules))): ?>
                    <li>
                        <a data-toggle="collapse" href="#laravel-examples5  " aria-expanded="true">
                            <i class="fab fa-laravel" ></i>
                            <span class="nav-link-text" ><?php echo e(__('Cars')); ?></span>
                            <b class="caret mt-1"></b>
                        </a>

                        <div class="<?php echo e($pageSlug == 'showroom' ? 'collapse.show' : ''); ?><?php echo e($pageSlug == 'showroomreview' ? 'collapse.show' : ''); ?><?php echo e($pageSlug == 'carlist'?'collapse.show':''); ?><?php echo e($pageSlug == 'carreviews'?'collapse.show':''); ?>collapse" id="laravel-examples5">
                            <ul class="nav pl-4">
                                <li class="<?php echo e($pageSlug == 'showroom' ? 'active':''); ?>" style="<?php echo e($pageSlug=='showroom'?'background-color:black':''); ?>">
                                    <a href="<?php echo e(route('showroom.index')); ?>">
                                        <i class="tim-icons icon-atom"></i>
                                        <p><?php echo e(__('Showroom List')); ?></p>
                                    </a>
                                </li>
                                <li class="<?php echo e($pageSlug == 'showroomreview' ? 'active':''); ?>" style="<?php echo e($pageSlug=='showroomreview'?'background-color:black':''); ?>">
                                    <a href="<?php echo e(route('showroomreview')); ?>">
                                        <i class="tim-icons icon-atom"></i>
                                        <p><?php echo e(__('Showroom Reviews')); ?></p>
                                    </a>
                                </li>
                                <li class="<?php echo e($pageSlug == 'carlist' ? 'active':''); ?>" style="<?php echo e($pageSlug=='carlist'?'background-color:black':''); ?>">
                                    <a href="<?php echo e(route('cars.index')); ?>">
                                        <i class="tim-icons icon-bullet-list-67"></i>
                                        <p><?php echo e(__('Cars List')); ?></p>
                                    </a>
                                </li>
                                <li class="<?php echo e($pageSlug == 'carreviews' ? 'active':''); ?>" style="<?php echo e($pageSlug=='carreviews'?'background-color:black':''); ?>">
                                    <a href="<?php echo e(route('carreview')); ?>">
                                        <i class="tim-icons icon-atom"></i>
                                        <p><?php echo e(__('Cars Reviews')); ?></p>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                <?php endif; ?>




















































            </ul>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\Usman\First Project\multi\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>