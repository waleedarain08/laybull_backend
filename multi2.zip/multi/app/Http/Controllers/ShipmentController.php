<?php

namespace App\Http\Controllers;

use App\Shipment;
use Illuminate\Http\Request;
use Validator;
use Auth;
use Octw\Aramex\Aramex;
use SoapClient;
class ShipmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $status=200;
        $message="apo";
        return response()->json(compact('status','message'),201);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $validator = Validator::make($request->all(),[
            'first_name'=>'required',
            'last_name'=>'required',
            'user_id'=>'required',
            'product_id' => 'required',
            'city' => 'required',
            'country'=>'required',
            'address_1' => 'required',
            'address_2' => 'required',
            'email' => 'required',
            'phone' => 'required',
            'discount_code'=>'required'
        ]);

        if($validator->fails()){
            return response()->json(['error'=>$validator->errors()],401);
        }

        $shipment = new Shipment();
        $shipment->user_id = $request->user_id;
        $shipment->product_id = $request->product_id;
        $shipment->first_name = $request->first_name;
        $shipment->last_name = $request->last_name;
        $shipment->email = $request->email;
        $shipment->phone = $request->phone;
        $shipment->address_1 = $request->address_1;
        $shipment->address_2 = $request->address_2;
        $shipment->city = $request->city;
        $shipment->country = $request->country;
        $shipment->discount_code = $request->discount_code;
        $shipment->shipment_cost = $request->shipment_cost;
        $shipment->currency_unit = $request->currency_unit;

        $shipment->save();

        $status = 'True';
        $message = 'shipment detail has been added SuccessFully.';
        return response()->json(compact('status','message'),201);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    public function list_of_sold_product(Request $request)
    {
        $data['list_of_sold_product']=Shipment::where('user_id',Auth::user()->id)->get();
        return response()->json(compact('data'),200);
    }
public function placeOrder(Request $request)
{
    $callResponse = Aramex::createShipment([
        'shipper' => [
            'name' => 'Steve',
            'email' => 'email@users.companies',
            'phone'      => '+123456789982',
            'cell_phone' => '+321654987789',
            'country_code' => 'US',
            'city' => 'New York',
            'zip_code' => 32160,
            'line1' => 'Line1 Details',
            'line2' => 'Line2 Details',
            'line3' => 'Line3 Details',
        ],
        'consignee' => [
            'name' => 'Steve',
            'email' => 'email@users.companies',
            'phone'      => '+123456789982',
            'cell_phone' => '+321654987789',
            'country_code' => 'US',
            'city' => 'New York',
            'zip_code' => 32160,
            'line1' => 'Line1 Details',
            'line2' => 'Line2 Details',
            'line3' => 'Line3 Details',
        ],
        'shipping_date_time' => time() + 50000,
        'due_date' => time() + 60000,
        'comments' => 'No Comment',
        'pickup_location' => 'at reception',
        // 'pickup_guid' => $guid,
        'weight' => 1,
        'number_of_pieces' => 1,
        'description' => 'Goods Description, like Boxes of flowers',
    ]);
    if (!empty($callResponse->error))
    {
        foreach ($callResponse->errors as $errorObject) {
            handleError($errorObject->Code, $errorObject->Message);
        }
    }
    else {
        // extract your data here, for example
         $shipmentId = $callResponse->Shipments->ProcessedShipment->ID;
         $labelUrl = $callResponse->Shipments->ProcessedShipment->ShipmentLabel->LabelURL;
    }
    return([$shipmentId, $labelUrl]);
}
}

