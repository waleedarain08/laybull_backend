<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReservationTransaction extends Model
{
    protected $table = 'reservation_transaction';
}
