<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FoodTransaction extends Model
{
    protected $table = 'food_transactions';
}
