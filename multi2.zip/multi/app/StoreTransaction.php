<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StoreTransaction extends Model
{
    protected $table = 'store_transactions';
}
